public interface Figura {
	double getArea();
	double getPerimetro();
	// ¡ya implementado en Object!
	String toString();
}
